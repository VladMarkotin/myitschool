<?php

$data = [
    "user1" => [
        "login"    => "name@example.com",
        "password" => '12345'
    ],
    "user2" => [
        "login"    => "qwerty2@gmail.com",
        "password" => '123456'
    ],
];
